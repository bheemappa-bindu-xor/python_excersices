# Creates a 10 MB text file filled with repeated text

FILE_SIZE = 10 * 1024 * 1024  # 10 MB

with open("10mb-examplefile-com.txt", "w") as f:
    while f.tell() < FILE_SIZE:
        f.write("This is sample data for the 10MB file.\n" * 1000)

print("10 MB text file created: 10mb-examplefile-com.txt")
