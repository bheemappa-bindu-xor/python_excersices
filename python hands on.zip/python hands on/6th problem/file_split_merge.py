import os
import threading

CHUNK_SIZE = 1 * 1024 * 1024  # 1 MB

# ----------------------------------------
# 1. SPLIT FILE INTO 1 MB CHUNKS
# ----------------------------------------

def split_file(input_file):
    chunk_sizes = []

    with open(input_file, "rb") as f:
        chunk_index = 0
        while True:
            data = f.read(CHUNK_SIZE)
            if not data:
                break

            chunk_name = f"chunk_{chunk_index}.bin"
            with open(chunk_name, "wb") as chunk_file:
                chunk_file.write(data)

            chunk_sizes.append(len(data))
            print(f"Created {chunk_name} ({len(data)} bytes)")

            chunk_index += 1

    return chunk_index, chunk_sizes


# ----------------------------------------
# 2. MERGE CHUNKS USING MULTIPLE THREADS
# ----------------------------------------

def merge_chunk(chunk_name, output_file, offset):
    with open(chunk_name, "rb") as c:
        data = c.read()

    with open(output_file, "r+b") as out:
        out.seek(offset)
        out.write(data)

    print(f"Merged {chunk_name}")


def merge_files(num_chunks, chunk_sizes, output_file):
    total_size = sum(chunk_sizes)

    # Create output file with exact size
    with open(output_file, "wb") as f:
        f.truncate(total_size)

    threads = []
    offset = 0

    for i in range(num_chunks):
        chunk_name = f"chunk_{i}.bin"
        t = threading.Thread(target=merge_chunk, args=(chunk_name, output_file, offset))
        threads.append(t)
        t.start()
        offset += chunk_sizes[i]

    for t in threads:
        t.join()


# ----------------------------------------
# 3. VERIFY FINAL FILE MATCHES ORIGINAL
# ----------------------------------------

def verify(original, merged):
    with open(original, "rb") as f1, open(merged, "rb") as f2:
        if f1.read() == f2.read():
            print("\n✅ Verification Passed: Files Match!")
        else:
            print("\n❌ Verification Failed: Files Do NOT Match!")


# ----------------------------------------
# MAIN
# ----------------------------------------

if __name__ == "__main__":
    original_file = "10mb-examplefile-com.txt"
    merged_output = "merged_output.txt"

    print("\n--- Splitting File ---")
    num_chunks, chunk_sizes = split_file(original_file)

    print("\n--- Merging Chunks with Threads ---")
    merge_files(num_chunks, chunk_sizes, merged_output)

    print("\n--- Verifying Output ---")
    verify(original_file, merged_output)

    print("\nDone!")
