import re

# Input log file
input_file = "feature.log"

# Output files
debug_file = "debug.log"
error_file = "error.log"
critical_file = "critical.log"

# Regex patterns to match log levels
debug_pattern = re.compile(r"\bDEBUG\b")
error_pattern = re.compile(r"\bERROR\b")
critical_pattern = re.compile(r"\bCRITICAL\b")

# Open output files
with open(debug_file, "w") as d_file, \
     open(error_file, "w") as e_file, \
     open(critical_file, "w") as c_file:
    
    try:
        # Read input log file
        with open(input_file, "r") as log_file:
            for line in log_file:
                if debug_pattern.search(line):
                    d_file.write(line)
                elif error_pattern.search(line):
                    e_file.write(line)
                elif critical_pattern.search(line):
                    c_file.write(line)
    except FileNotFoundError:
        print(f"Error: {input_file} not found.")
    except Exception as e:
        print("An error occurred:", e)

print("Log extraction complete!")
