import json

try:
    with open("intf.json", "r") as f:
        data = json.load(f)

    try:
        name = data["interface"]["name"]
        type_ = data["interface"]["type"]
        ipv4 = data["interface"]["ipv4"]["address"]
        prefix = data["interface"]["ipv4"]["prefix-length"]

        in_octets = data["interface"]["counters"]["in-octets"]
        in_unicast = data["interface"]["counters"]["in-unicast-pkts"]
        out_octets = data["interface"]["counters"]["out-octets"]
        out_unicast = data["interface"]["counters"]["out-unicast-pkts"]

        print("name :", name)
        print("type:", type_)
        print("Ipv4 address:", ipv4)
        print("Prefix length:", prefix)
        print("in octets:", in_octets)
        print("in unicast pkts:", in_unicast)
        print("out octets:", out_octets)
        print("out unicast pkts:", out_unicast)

    except KeyError as e:
        print(f"Error: Key not found in JSON → {e}")

except FileNotFoundError:
    print("Error: intf.json file not found.")
except json.JSONDecodeError:
    print("Error: Invalid JSON format.")
