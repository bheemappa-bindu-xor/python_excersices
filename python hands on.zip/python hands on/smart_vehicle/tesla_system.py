# Base Vehicle class
class Vehicle:
    def __init__(self):
        self.running = False

    def start(self):
        if not self.running:
            print("Vehicle is starting...")
            self.running = True
        else:
            print("Vehicle is already running.")

    def stop(self):
        if self.running:
            print("Vehicle is stopping...")
            self.running = False
        else:
            print("Vehicle is already stopped.")

# Car subclass
class Car(Vehicle):
    def __init__(self):
        super().__init__()
        self.music_on = False

    def play_music(self):
        if self.running:
            self.music_on = True
            print("Playing music in the car...")
        else:
            print("Cannot play music. Start the car first.")

    def stop_music(self):
        if self.music_on:
            self.music_on = False
            print("Music stopped.")
        else:
            print("Music is already off.")

# ElectricMixin
class ElectricMixin:
    def __init__(self):
        self.battery_level = 100  # percentage
        super().__init__()

    def start(self):
        if self.battery_level < 20:
            print("Warning: Battery low! Charge before starting.")
        else:
            print(f"Battery level: {self.battery_level}% - OK")
        super().start()

# AutopilotMixin
class AutopilotMixin:
    def __init__(self):
        self.autopilot_active = False
        super().__init__()

    def start(self):
        print("Calibrating sensors for autopilot...")
        super().start()

    def enable_autopilot(self):
        if self.running:
            self.autopilot_active = True
            print("Autopilot enabled.")
        else:
            print("Start the car first to enable autopilot.")

    def disable_autopilot(self):
        if self.autopilot_active:
            self.autopilot_active = False
            print("Autopilot disabled.")
        else:
            print("Autopilot is already off.")

# Tesla class using multiple inheritance
class Tesla(AutopilotMixin, ElectricMixin, Car):
    def __init__(self):
        super().__init__()

# Testing the enhanced Tesla
if __name__ == "__main__":
    my_tesla = Tesla()

    # Start the Tesla
    my_tesla.start()

    # Play music
    my_tesla.play_music()

    # Enable autopilot
    my_tesla.enable_autopilot()

    # Stop music
    my_tesla.stop_music()

    # Disable autopilot
    my_tesla.disable_autopilot()

    # Stop the Tesla
    my_tesla.stop()
